/***  Database default init routine  ***/
/***  Generated automatically using the dbin tool. */
/***  Not to be modified by user. */
#include "mcf_ntubld_db.h"
void mcf_ntubldInit() {

/***** template line_title *****/
/*   char line " "  */
/* end template */
*n_obj_line_title=0;

/***** template header *****/
/*     char title  */
/*     char version */
/*     char nameMaxIndex */
/*     int maxMult */
/*     int orgStyle */
/*     int nVar */
/* end template */
*n_obj_header=0;

/***** template variable *****/
/*     char name  */
/*     char description  */
/*     int  type    */
/*     char isFixedSize */
/*     int  numDim  */
/*     int  dimensions(5) */
/* end template  */
*n_obj_variable=0;
}
