/*******************************************************************************
*									       *
* mcf_NTuBldMenu.h --    						       *
*									       *
*	P. Lebrun, September 1995.					       *
*									       *
*******************************************************************************/
Widget CreateNTuBldMenuBar(Widget main, nTuBuildWindow *window);
