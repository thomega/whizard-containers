/* SCCS ID: rotation.h 1.1 4/6/92 */
void ShowAbsRotationPanel(StdHepWindow *window);
void UpdateRotationPanel(StdHepWindow *window);
