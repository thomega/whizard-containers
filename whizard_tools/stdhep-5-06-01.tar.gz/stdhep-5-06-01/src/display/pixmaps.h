/* SCCS ID: pixmaps.h 1.1 4/6/92 */
void RegisterPhaseBitmaps(Screen *screen);
