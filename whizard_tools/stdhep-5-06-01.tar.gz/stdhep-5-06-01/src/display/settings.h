/* SCCS ID: settings.h 1.1 4/6/92 */
void ShowVectorLengthPanel(PhaseWindow *window);
void ShowButtonRotationPanel(StdHepWindow *window);
