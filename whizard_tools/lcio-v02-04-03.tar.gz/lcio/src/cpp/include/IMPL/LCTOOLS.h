/**
 * LCTools have moved from namespace IMPL to namesapce UTIL.
 * Please use #include "UTIL/LCTOOLS.h"
 */

#include "UTIL/LCTOOLS.h"
