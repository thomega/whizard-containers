from base.SetupLcioDictionary import setupLcioDictionary
setupLcioDictionary()

from base.DecorateLcioClasses import decorateLcioClasses
decorateLcioClasses()

from ROOT import EVENT, IMPL, IO, IOIMPL, UTIL