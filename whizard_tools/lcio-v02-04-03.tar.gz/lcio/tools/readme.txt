Libraries used when compiling AIDA

This directory contains all libraries needed when you COMPILE AIDA.


Each library specfies name, version number, description and their origin

ant.jar, ant-optional.jar, jaxp.jar, parser.jar
    1.3
    Jakarta-ANT: Make for Java
    http://jakarta.apache.org/

bcel.jar
    5.0
    Byte-Code Engineering Library
    http://jakarta.apache.org/

freehep-base.jar, freehep-tools.jar, freehep-buildtools.jar
    1.1
    FreeHEP
    http://java.freehep.org/

jel.jar
    0.9.10
    Java Expressions Library
    http://galaxy.fzu.cz/JEL/

saxpath.jar
    1.0 FCS
    SAXPATH
    http://saxpath.sourceforge.net/

sio.jar

jdom.jar
    beta9
    JDOM
    http://www.jdom.org/

jaxen-core, jaxen-jdom
    1.0 FCS
    Jaxen
    http://jaxen.sourceforge.net/

       